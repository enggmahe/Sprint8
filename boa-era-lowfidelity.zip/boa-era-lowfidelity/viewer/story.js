var story = {
"docName": "boa-era-lowfidelity",
"docPath": "P_P_P",
"docVersion": "V_V_V",
"hasRetina": false,
"serverToolsPath":"",
"fileType":"png",
"disableHotspots": false,
"pages": [
$.extend(new ViewerPage(),{
"index": 0,
"image": "2.png",
"width": 1440,
"height": 1024,
"title": "2",
'transAnimType': 0,
'layout' : {
	"offset": 0,
	"totalWidth": 960,
	"numberOfColumns": 12,
	"columnWidth": 60,
	"gutterWidth": 20
},
'type': 'regular',
'fixedPanels': [],
'links' : [
	{
		"rect": {
			"x": 0,
			"y": 0,
			"width": 1440,
			"height": 90
		},
		"isParentFixed": false,
		"page": 6,
		"index": 0
	},
	{
		"rect": {
			"x": 1125,
			"y": 398,
			"width": 63,
			"height": 51
		},
		"isParentFixed": false,
		"page": 1,
		"index": 1
	},
	{
		"rect": {
			"x": 1208,
			"y": 398,
			"width": 63,
			"height": 51
		},
		"isParentFixed": false,
		"page": 2,
		"index": 2
	}
],
})
,$.extend(new ViewerPage(),{
"index": 1,
"image": "3.png",
"width": 1440,
"height": 1024,
"title": "3",
'transAnimType': 0,
'layout' : {
	"offset": 0,
	"totalWidth": 960,
	"numberOfColumns": 12,
	"columnWidth": 60,
	"gutterWidth": 20
},
'type': 'regular',
'fixedPanels': [],
'links' : [
	{
		"rect": {
			"x": 0,
			"y": 0,
			"width": 1440,
			"height": 90
		},
		"isParentFixed": false,
		"page": 6,
		"index": 0
	},
	{
		"rect": {
			"x": 1412,
			"y": 190,
			"width": 16,
			"height": 16
		},
		"isParentFixed": false,
		"page": 2,
		"index": 1
	},
	{
		"rect": {
			"x": 50,
			"y": 114,
			"width": 341,
			"height": 11
		},
		"isParentFixed": false,
		"page": 6,
		"index": 2
	}
],
})
,$.extend(new ViewerPage(),{
"index": 2,
"image": "4.png",
"width": 1440,
"height": 1024,
"title": "4",
'transAnimType': 0,
'layout' : {
	"offset": 0,
	"totalWidth": 960,
	"numberOfColumns": 12,
	"columnWidth": 60,
	"gutterWidth": 20
},
'type': 'regular',
'fixedPanels': [],
'links' : [
	{
		"rect": {
			"x": 0,
			"y": 0,
			"width": 1440,
			"height": 90
		},
		"isParentFixed": false,
		"page": 6,
		"index": 0
	},
	{
		"rect": {
			"x": 1412,
			"y": 165,
			"width": 16,
			"height": 16
		},
		"isParentFixed": false,
		"page": 1,
		"index": 1
	},
	{
		"rect": {
			"x": 50,
			"y": 114,
			"width": 364,
			"height": 11
		},
		"isParentFixed": false,
		"page": 6,
		"index": 2
	},
	{
		"rect": {
			"x": 50,
			"y": 175,
			"width": 1318,
			"height": 30
		},
		"isParentFixed": false,
		"page": 4,
		"index": 3
	},
	{
		"rect": {
			"x": 50,
			"y": 338,
			"width": 1318,
			"height": 54
		},
		"isParentFixed": false,
		"page": 3,
		"index": 4
	}
],
})
,$.extend(new ViewerPage(),{
"index": 3,
"image": "5.png",
"width": 1440,
"height": 2318,
"title": "5",
'transAnimType': 0,
'layout' : {
	"offset": 0,
	"totalWidth": 960,
	"numberOfColumns": 12,
	"columnWidth": 60,
	"gutterWidth": 20
},
'type': 'regular',
'fixedPanels': [],
'links' : [
	{
		"rect": {
			"x": 0,
			"y": 0,
			"width": 1440,
			"height": 90
		},
		"isParentFixed": false,
		"page": 6,
		"index": 0
	},
	{
		"rect": {
			"x": 50,
			"y": 114,
			"width": 364,
			"height": 11
		},
		"isParentFixed": false,
		"page": 6,
		"index": 1
	},
	{
		"rect": {
			"x": 50,
			"y": 336,
			"width": 1318,
			"height": 54
		},
		"isParentFixed": false,
		"page": 2,
		"index": 2
	}
],
})
,$.extend(new ViewerPage(),{
"index": 4,
"image": "6.png",
"width": 1440,
"height": 1024,
"title": "6",
'transAnimType': 0,
'layout' : {
	"offset": 0,
	"totalWidth": 960,
	"numberOfColumns": 12,
	"columnWidth": 60,
	"gutterWidth": 20
},
'type': 'regular',
'fixedPanels': [],
'links' : [
	{
		"rect": {
			"x": 0,
			"y": 0,
			"width": 1440,
			"height": 90
		},
		"isParentFixed": false,
		"page": 6,
		"index": 0
	},
	{
		"rect": {
			"x": 1412,
			"y": 165,
			"width": 16,
			"height": 16
		},
		"isParentFixed": false,
		"page": 1,
		"index": 1
	},
	{
		"rect": {
			"x": 50,
			"y": 114,
			"width": 364,
			"height": 11
		},
		"isParentFixed": false,
		"page": 6,
		"index": 2
	},
	{
		"rect": {
			"x": 50,
			"y": 175,
			"width": 1318,
			"height": 30
		},
		"isParentFixed": false,
		"page": 2,
		"index": 3
	},
	{
		"rect": {
			"x": 50,
			"y": 388,
			"width": 1318,
			"height": 54
		},
		"isParentFixed": false,
		"page": 3,
		"index": 4
	},
	{
		"rect": {
			"x": 52,
			"y": 213,
			"width": 228,
			"height": 48
		},
		"isParentFixed": false,
		"page": 5,
		"index": 5
	}
],
})
,$.extend(new ViewerPage(),{
"index": 5,
"image": "7.png",
"width": 1440,
"height": 1024,
"title": "7",
'transAnimType': 0,
'layout' : {
	"offset": 0,
	"totalWidth": 960,
	"numberOfColumns": 12,
	"columnWidth": 60,
	"gutterWidth": 20
},
'type': 'regular',
'fixedPanels': [],
'links' : [
	{
		"rect": {
			"x": 0,
			"y": 0,
			"width": 1440,
			"height": 90
		},
		"isParentFixed": false,
		"page": 6,
		"index": 0
	},
	{
		"rect": {
			"x": 1412,
			"y": 165,
			"width": 16,
			"height": 16
		},
		"isParentFixed": false,
		"page": 1,
		"index": 1
	},
	{
		"rect": {
			"x": 50,
			"y": 114,
			"width": 364,
			"height": 11
		},
		"isParentFixed": false,
		"page": 6,
		"index": 2
	},
	{
		"rect": {
			"x": 50,
			"y": 388,
			"width": 1318,
			"height": 54
		},
		"isParentFixed": false,
		"page": 3,
		"index": 3
	},
	{
		"rect": {
			"x": 50,
			"y": 213,
			"width": 330,
			"height": 194
		},
		"isParentFixed": false,
		"page": 4,
		"index": 4
	}
],
})
,$.extend(new ViewerPage(),{
"index": 6,
"image": "1.png",
"width": 1440,
"height": 1024,
"title": "1",
'transAnimType': 0,
'layout' : {
	"offset": 0,
	"totalWidth": 960,
	"numberOfColumns": 12,
	"columnWidth": 60,
	"gutterWidth": 20
},
'type': 'regular',
'fixedPanels': [],
'links' : [
	{
		"rect": {
			"x": 1412,
			"y": 110,
			"width": 16,
			"height": 16
		},
		"isParentFixed": false,
		"page": 0,
		"index": 0
	}
],
})
   ]
,"resolutions": [1],
"zoomEnabled": true,
"title": "boa-era-lowfidelity",
"startPageIndex": 0,
"layersExist": true,
"centerContent":  false,
"totalImages": 7,
"highlightLinks": false
}
